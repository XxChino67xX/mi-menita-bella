MI MENITA HERMOSA — INSTRUCCIONES

ARCHIVOS
- index.html: contenido de la página.
- style.css: colores, tamaños y animaciones.
- script.js: interacciones, carta, lluvia y reproductores.
- fotos/: fotografías personales y portadas de canciones.
- musica/: archivos de audio MP3.

EJECUTAR EN KALI LINUX
1. Extrae la carpeta del ZIP.
2. Abre una terminal dentro de la carpeta mi-menita-hermosa.
3. Ejecuta: python3 -m http.server 8000
4. Abre http://localhost:8000 en tu navegador.
5. Para detener el servidor, vuelve a la terminal y pulsa Ctrl+C.

AGREGAR FOTOS A LA GALERÍA
Copia tus fotos a fotos/ y nómbralas exactamente recuerdo1.png, recuerdo2.png y recuerdo3.png.

AGREGAR FOTO A CADA CANCIÓN (OPCIONAL)
- Portada de Tristella: fotos/cancion-tristella.jpg
- Portada de Piel Canela: fotos/cancion-piel-canela.jpg
Usa imágenes que tengas permiso de compartir. Si no agregas portada, aparecerá un diseño decorativo.

AGREGAR LAS CANCIONES
Copia archivos MP3 que tengas derecho a usar dentro de musica/ con estos nombres exactos:
- musica/tristella-esperon.mp3
- musica/piel-canela-cuco.mp3
Los nombres deben coincidir exactamente, incluyendo guiones y extensión. No se incluyen archivos musicales por derechos de autor.

PUBLICAR GRATIS
Puedes subir los archivos del proyecto a un repositorio de GitHub y activar Settings > Pages.
Antes de publicar, recuerda que cualquier persona con acceso al enlace puede ver las fotos y archivos públicos. No subas fotos privadas sin consentimiento.
